
package agenda;

class Contacto {
    String nombre;
    String apellidoP;
    String apellidoM;
    
    
}
