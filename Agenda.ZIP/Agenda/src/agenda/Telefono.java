package agenda;

class Telefono {
    int celular;
    int casa;
    int trabajo;
    int privado;
    int otro;
}
