
package agenda;


class Redsocial {
String facebook;
String  twiter;
String paginaweb;
String correo;
String otra;
}
