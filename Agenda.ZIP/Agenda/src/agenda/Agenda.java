package agenda;
import java.util.ArrayList;
import java.util.Scanner;

public class Agenda {
    private String nombrecontacto;
   private ArrayList<String> contactos;
   private ArrayList<Telefono> telefonos; 
   private ArrayList<String> redsocial;   
   public Agenda(String contacto){
   nombrecontacto=contacto;
   contactos= new  ArrayList<String>(); 
   }
   
   public void addNombre(String valor_contacto){contactos.add (valor_contacto);}
   public String getNombre(int posicion){
       if(posicion>=0&&posicion<contactos.size()){
           return contactos.get(posicion);
       }else{
           return "no existe nombre para la posicion solicitada";}
   }
   public int getTamaño(){
       return contactos.size();
   }
public void borraNombre(int posicion){
    if(posicion>=0&&posicion<contactos.size()){
        contactos.remove(posicion);
    }else{}
}



    public static void main(String[] args) {
        
        Scanner in = new Scanner(System.in);
        String nombre;
     System.out.println("bienvenido a la agenda");
     System.out.println("introduzca el nombre 1");
    nombre = in.next();
     System.out.println("gracias");
     Agenda lista1= new Agenda("lista de nombres");
     lista1.addNombre(nombre);
     System.out.println("La lista a quedado formada por" +lista1.getTamaño()+"elementos");
     System.out.println("elemento 1:"+lista1.getNombre(0));
     
    }
    
}
